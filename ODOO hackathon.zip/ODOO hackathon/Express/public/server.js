const express = require('express');
const path = require('path');
const {
  createPool
} = require("mysql");
const app = express();
const bodyparser = require("body-parser")
// const app = express();
// var sp = path.join(__dirname, "../public")
app.use(bodyparser.urlencoded())

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, "views"));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, "./views")));
app.use(express.static(path.join(__dirname, "../public")));

const pool = createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "project",
  connectionLimit: 10
})

// Import routes
// // const indexRouter = require('./routes/index');
// const furnitureRouter = require('./routes/furniture');
// const loginRouter = require('./routes/login');
// const registerRouter = require('./routes/register');

// app.use(express.static(path.join(__dirname, '../views'))); // Assuming static files are in 'public' folder

// Define routes
app.get('/', (req, res) => {
  res.render('index'); // Render the EJS file (e.g., 'index.ejs')
});

// Use routes
// app.use('/', indexRouter);
// app.use('/furniture', furnitureRouter);
// app.use('/login', loginRouter);
// app.use('/register', registerRouter);

const PORT = process.env.PORT || 3000;
app.post("/login", (req, res) => {
  res.render('index');
  console.log(req.body.email);
  var data1 = req.body.email;
  res.render("index", {
    data : data1,
  });
})
pool.query("select * from furniture limit 10", (err, result, fields) => {
  res = result;
  counter = 1;
  for (let i of result) {
    var id = i.ID;
    var name = i.Name;
    var material = i.Material;
    var color = i.Price;
    var category = i.Category;
    var rental_price = i.Rental_price;

    // var x = document.getElementById(counter.toString());
    // x.innerHTML=id;

  }

});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});