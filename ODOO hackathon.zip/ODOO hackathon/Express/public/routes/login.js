const express = require('express');
const router = express.Router();
const path = require('path');
const bodyparser=require("body-parser")
const app=express();
var sp=path.join(__dirname,"../public")
app.use(bodyparser.urlencoded())

router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../login.html'));
});
app.post("/login",(req,res)=>{
  console.log(req.body.uname);
})


module.exports = router;
